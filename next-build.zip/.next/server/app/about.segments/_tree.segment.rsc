:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/3dn1wlx9p-fsk.css","style"]
:HL["/_next/static/chunks/1ta955ki9zd5h.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"about","h":96,"c":"$Q2"}]]
0:{"b":"eEoA9JFVK_hJchRv0k7Y3","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
