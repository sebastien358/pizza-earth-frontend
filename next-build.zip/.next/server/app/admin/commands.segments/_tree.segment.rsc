:HL["/_next/static/chunks/20_y0l37x0yi8.css","style"]
:HL["/_next/static/chunks/319pfmcev6wpg.css","style"]
:HL["/_next/static/chunks/3ubm5g3g194nb.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"commands","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"vJRAXyd4O7ya_SGFKzEh-","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
