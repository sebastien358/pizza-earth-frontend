:HL["/_next/static/chunks/0tf7fnxdmucs9.css","style"]
:HL["/_next/static/chunks/0-779sp-1_zos.css","style"]
:HL["/_next/static/chunks/2p3hdei4ohf-8.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"products","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"-aawjzM7-hfNY9i1Z917T","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
