:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/3dn1wlx9p-fsk.css","style"]
:HL["/_next/static/chunks/2vg-fvqyqg24o.css","style"]
:HL["/_next/static/chunks/0p0_8y3mohqp6.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"products","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"eEoA9JFVK_hJchRv0k7Y3","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
