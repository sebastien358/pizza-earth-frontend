:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/20ufwueowoujb.css","style"]
:HL["/_next/static/chunks/2hig9ts26kb4u.css","style"]
4:[["children",{"s":"__PAGE__","h":160}]]
3:[["children",{"s":"form","h":96,"c":"$Q4"}]]
2:[["children",{"s":"products","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"VbNVT5iul8a3PfjM0mOD3","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
