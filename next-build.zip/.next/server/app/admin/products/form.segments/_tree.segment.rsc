:HL["/_next/static/chunks/0tf7fnxdmucs9.css","style"]
:HL["/_next/static/chunks/0uk49a1n-51yc.css","style"]
:HL["/_next/static/chunks/1wmpt21smxfii.css","style"]
4:[["children",{"s":"__PAGE__","h":160}]]
3:[["children",{"s":"form","h":96,"c":"$Q4"}]]
2:[["children",{"s":"products","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"5DGa8jPE0JzwAo483VlvW","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
