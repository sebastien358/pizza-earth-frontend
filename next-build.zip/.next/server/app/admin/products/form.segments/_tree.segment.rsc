:HL["/_next/static/chunks/0o8e89e-w_04t.css","style"]
:HL["/_next/static/chunks/16wlukoru9o2u.css","style"]
:HL["/_next/static/chunks/1wmpt21smxfii.css","style"]
4:[["children",{"s":"__PAGE__","h":160}]]
3:[["children",{"s":"form","h":96,"c":"$Q4"}]]
2:[["children",{"s":"products","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"I4zk2RMmXtleTAPuPpJYQ","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
