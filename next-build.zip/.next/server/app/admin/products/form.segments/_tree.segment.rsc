:HL["/_next/static/chunks/20_y0l37x0yi8.css","style"]
:HL["/_next/static/chunks/319pfmcev6wpg.css","style"]
:HL["/_next/static/chunks/3e_yw7263tapa.css","style"]
4:[["children",{"s":"__PAGE__","h":160}]]
3:[["children",{"s":"form","h":96,"c":"$Q4"}]]
2:[["children",{"s":"products","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"jXYo_QRXzJYzsoB6_3jOh","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
