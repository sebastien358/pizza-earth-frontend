:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/2wpba05ey74xz.css","style"]
:HL["/_next/static/chunks/3t3e_bccdb0by.css","style"]
4:[["children",{"s":"__PAGE__","h":160}]]
3:[["children",{"s":"form","h":96,"c":"$Q4"}]]
2:[["children",{"s":"products","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"b63Qyd4hGKODI8auY6kML","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
