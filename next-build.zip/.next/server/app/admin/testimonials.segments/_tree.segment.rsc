:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/2wpba05ey74xz.css","style"]
:HL["/_next/static/chunks/2on3lpde8tlx-.css","style"]
:HL["/_next/static/chunks/36uv11guu512_.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"testimonials","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"b63Qyd4hGKODI8auY6kML","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
