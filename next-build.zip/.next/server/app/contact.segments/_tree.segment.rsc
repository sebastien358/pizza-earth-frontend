:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/3dn1wlx9p-fsk.css","style"]
:HL["/_next/static/chunks/0ioik5hsl2-aw.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"contact","h":96,"c":"$Q2"}]]
0:{"b":"or0jFDqGhvHcrTSqLpwbh","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
