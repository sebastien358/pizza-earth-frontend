:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/0hbzf_k1kh1d0.css","style"]
:HL["/_next/static/chunks/2txcdo9yxud_b.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"legal-notice","h":96,"c":"$Q2"}]]
0:{"b":"Vb1BKrVLV2MWYAoKT0Zis","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
