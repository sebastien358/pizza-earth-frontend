:HL["/_next/static/chunks/0o8e89e-w_04t.css","style"]
:HL["/_next/static/chunks/16wlukoru9o2u.css","style"]
:HL["/_next/static/chunks/2txcdo9yxud_b.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"legal-notice","h":96,"c":"$Q2"}]]
0:{"b":"I4zk2RMmXtleTAPuPpJYQ","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
