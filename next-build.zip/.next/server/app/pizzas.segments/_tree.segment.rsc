:HL["/_next/static/chunks/0tf7fnxdmucs9.css","style"]
:HL["/_next/static/chunks/0uk49a1n-51yc.css","style"]
:HL["/_next/static/chunks/1nqzvjiywrhla.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"pizzas","h":96,"c":"$Q2"}]]
0:{"b":"5DGa8jPE0JzwAo483VlvW","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
