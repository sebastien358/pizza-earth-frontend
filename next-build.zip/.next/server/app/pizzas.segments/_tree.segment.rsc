:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/0hbzf_k1kh1d0.css","style"]
:HL["/_next/static/chunks/1jg7u55drz7h4.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"pizzas","h":96,"c":"$Q2"}]]
0:{"b":"2PAwEowg7yvXSPONyAeio","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
