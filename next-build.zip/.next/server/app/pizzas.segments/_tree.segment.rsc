:HL["/_next/static/chunks/0o8e89e-w_04t.css","style"]
:HL["/_next/static/chunks/16wlukoru9o2u.css","style"]
:HL["/_next/static/chunks/0sh66zqvc4cdp.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"pizzas","h":96,"c":"$Q2"}]]
0:{"b":"I4zk2RMmXtleTAPuPpJYQ","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
