:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/20ufwueowoujb.css","style"]
:HL["/_next/static/chunks/1jg7u55drz7h4.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"pizzas","h":96,"c":"$Q2"}]]
0:{"b":"VbNVT5iul8a3PfjM0mOD3","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
