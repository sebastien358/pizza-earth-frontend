:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/3_1i8npu3-iag.css","style"]
:HL["/_next/static/chunks/051dovrxu12vg.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"pizzas","h":96,"c":"$Q2"}]]
0:{"b":"ZjhMFailepwJ3uIeHcBUo","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
