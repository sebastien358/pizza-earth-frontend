:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/0hbzf_k1kh1d0.css","style"]
:HL["/_next/static/chunks/3qy0jzltu4dmk.css","style"]
:HL["/_next/static/chunks/3u5z3rz8dxf53.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"reviews","h":96,"c":"$Q2"}]]
0:{"b":"Eg7siwV02dnxszICRcQfu","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
