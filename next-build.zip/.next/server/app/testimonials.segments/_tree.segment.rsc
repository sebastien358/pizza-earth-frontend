:HL["/_next/static/chunks/3cnjrwb433sxw.css","style"]
:HL["/_next/static/chunks/3dn1wlx9p-fsk.css","style"]
:HL["/_next/static/chunks/23nt-dp8w59xx.css","style"]
:HL["/_next/static/chunks/1645fl0cmkhai.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"testimonials","h":96,"c":"$Q2"}]]
0:{"b":"or0jFDqGhvHcrTSqLpwbh","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
