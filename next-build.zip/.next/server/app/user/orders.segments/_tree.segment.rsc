:HL["/_next/static/chunks/0o8e89e-w_04t.css","style"]
:HL["/_next/static/chunks/16wlukoru9o2u.css","style"]
:HL["/_next/static/chunks/05084r9hsxcwo.css","style"]
:HL["/_next/static/chunks/1m9unoeq_oza9.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"orders","h":96,"c":"$Q3"}]]
1:[["children",{"s":"user","h":96,"c":"$Q2"}]]
0:{"b":"I4zk2RMmXtleTAPuPpJYQ","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
