:HL["/_next/static/chunks/3-3s3z5pewqi_.css","style"]
:HL["/_next/static/chunks/1j4jvw0k8zn2c.css","style"]
:HL["/_next/static/chunks/05084r9hsxcwo.css","style"]
:HL["/_next/static/chunks/1m9unoeq_oza9.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"orders","h":96,"c":"$Q3"}]]
1:[["children",{"s":"user","h":96,"c":"$Q2"}]]
0:{"b":"m5FPOOQ6fyDUyyJ0ty7B2","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
