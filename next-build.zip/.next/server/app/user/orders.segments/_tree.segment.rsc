:HL["/_next/static/chunks/20_y0l37x0yi8.css","style"]
:HL["/_next/static/chunks/319pfmcev6wpg.css","style"]
:HL["/_next/static/chunks/05084r9hsxcwo.css","style"]
:HL["/_next/static/chunks/1f8t9xgksh2dv.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"orders","h":96,"c":"$Q3"}]]
1:[["children",{"s":"user","h":96,"c":"$Q2"}]]
0:{"b":"jXYo_QRXzJYzsoB6_3jOh","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
