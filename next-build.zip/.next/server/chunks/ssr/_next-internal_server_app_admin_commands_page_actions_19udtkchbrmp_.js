module.exports=[8543,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_commands_page_actions_19udtkchbrmp_.js.map