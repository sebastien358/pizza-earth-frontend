module.exports=[6566,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_products_form_%5Bid%5D_page_actions_06oww78-rxjck.js.map