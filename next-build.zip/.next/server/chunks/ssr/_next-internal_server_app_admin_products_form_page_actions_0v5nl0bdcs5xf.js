module.exports=[81867,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_products_form_page_actions_0v5nl0bdcs5xf.js.map