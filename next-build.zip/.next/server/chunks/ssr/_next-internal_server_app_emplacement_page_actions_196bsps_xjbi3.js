module.exports=[5394,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_emplacement_page_actions_196bsps_xjbi3.js.map