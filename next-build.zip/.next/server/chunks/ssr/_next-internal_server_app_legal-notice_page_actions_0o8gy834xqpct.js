module.exports=[5956,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_legal-notice_page_actions_0o8gy834xqpct.js.map