module.exports=[52866,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pizzas_page_actions_1-8teir20tyz1.js.map