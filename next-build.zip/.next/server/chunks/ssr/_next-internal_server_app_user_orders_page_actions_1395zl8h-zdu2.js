module.exports=[85912,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_user_orders_page_actions_1395zl8h-zdu2.js.map