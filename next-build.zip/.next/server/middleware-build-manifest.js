globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/m5FPOOQ6fyDUyyJ0ty7B2/_buildManifest.js",
    "static/m5FPOOQ6fyDUyyJ0ty7B2/_ssgManifest.js",
    "static/m5FPOOQ6fyDUyyJ0ty7B2/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3be5ypa669k_3.js",
    "static/chunks/1k2w3nq2-wg_-.js",
    "static/chunks/378xqf-ccupql.js",
    "static/chunks/1r4tpu9kyu516.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/commands/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/products/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/products/form/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/products/form/[id]/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/cart/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/emplacement/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/pizzas/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/register/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/user/orders/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/user/payment/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/1k2w3nq2-wg_-.js",
        "static/chunks/378xqf-ccupql.js",
        "static/chunks/1r4tpu9kyu516.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
